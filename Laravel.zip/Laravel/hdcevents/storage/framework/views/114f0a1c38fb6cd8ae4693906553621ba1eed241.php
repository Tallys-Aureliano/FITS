<h1>sou a pagina de contatos</h1>
<a href="/">voltar para home</a><?php /**PATH C:\Users\letic\OneDrive\Documents\Laravel\hdcevents\resources\views/content.blade.php ENDPATH**/ ?>