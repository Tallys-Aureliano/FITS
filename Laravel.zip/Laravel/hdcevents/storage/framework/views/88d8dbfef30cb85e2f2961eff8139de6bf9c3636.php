
<?php $__env->startSection('title','produtos'); ?>
<?php $__env->startSection('content'); ?>
    <h1>tela de produtos</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\letic\OneDrive\Documents\Laravel\hdcevents\resources\views/produtos.blade.php ENDPATH**/ ?>